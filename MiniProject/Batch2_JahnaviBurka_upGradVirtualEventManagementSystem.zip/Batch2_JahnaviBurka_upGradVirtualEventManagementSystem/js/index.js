// Load dynamic events from IndexedDB
let db;
let request = indexedDB.open("EventDB", 1);

/* Create DB */
request.onupgradeneeded = function(e){
  db = e.target.result;

  if(!db.objectStoreNames.contains("events")){
    db.createObjectStore("events", { keyPath: "id" });
  }
};

/* When DB opens */
request.onsuccess = function(e){
  db = e.target.result;

  insertDefaultEvents();   // insert first
};

request.onerror = function(e){
  console.error("Database error: ", e.target.error);
};

/* ✅ Insert default events ONLY if DB empty */
function insertDefaultEvents(){
  let tx = db.transaction("events", "readonly");
  let store = tx.objectStore("events");

  let countRequest = store.count();

  countRequest.onsuccess = function(){
    if(countRequest.result === 0){

      let tx2 = db.transaction("events", "readwrite");
      let store2 = tx2.objectStore("events");

      store2.add({
        id: "EVT101",
        name: "AI Conference",
        category: "Tech",
        date: "20 June 2026",
        time: "10:00 AM"
      });

      store2.add({
        id: "EVT102",
        name: "Industrial Summit",
        category: "Industrial",
        date: "25 June 2026",
        time: "02:00 PM"
      });

      // ✅ IMPORTANT: wait until insert completes
      tx2.oncomplete = function(){
        displayDynamicEvents();
      };

    } else {
      // ✅ If already data exists, just display
      displayDynamicEvents();
    }
  };
}

/* Display Events */
function displayDynamicEvents(){
  let eventsList = document.getElementById("eventsList");
  eventsList.innerHTML = ""; // clear to avoid duplicates

  let transaction = db.transaction(["events"], "readonly");
  let store = transaction.objectStore("events");
  let cursorRequest = store.openCursor();

  cursorRequest.onsuccess = function(e){
    let cursor = e.target.result;

    if(cursor){
      let event = cursor.value;

      let card = document.createElement("div");
      card.className = "col-md-4";

      card.innerHTML = `
        <div class="card event-card p-3 text-center">
          <h5><u>${event.name}</u></h5>
          <p><b>Event ID:</b> ${event.id}</p>
          <p><b>Category:</b> ${event.category}</p>
          <p><b>Date:</b> ${event.date}</p>
          <p><b>Time:</b> ${event.time}</p>
          <a href="register.html?eventId=${event.id}&name=${encodeURIComponent(event.name)}&category=${encodeURIComponent(event.category)}&date=${encodeURIComponent(event.date)}&time=${encodeURIComponent(event.time)}" 
             class="btn btn-primary register-btn">
             Register
          </a>
        </div>
      `;

      eventsList.appendChild(card);
      cursor.continue();
    }
  };
}