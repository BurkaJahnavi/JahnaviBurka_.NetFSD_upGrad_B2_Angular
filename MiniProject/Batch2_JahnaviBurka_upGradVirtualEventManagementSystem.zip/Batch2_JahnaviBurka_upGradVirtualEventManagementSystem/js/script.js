function login(){

let email=document.getElementById("email").value;
let password=document.getElementById("password").value;

if(email==="admin@upgrad.com" && password==="12345")
{
localStorage.setItem("login","true");
window.location="events.html";
}
else
{
alert("Invalid Login Credentials");
}

}

function logout(){

localStorage.removeItem("login");
window.location="login.html";

}

function registerEvent(){

alert("You are successfully registered to this event!");

}