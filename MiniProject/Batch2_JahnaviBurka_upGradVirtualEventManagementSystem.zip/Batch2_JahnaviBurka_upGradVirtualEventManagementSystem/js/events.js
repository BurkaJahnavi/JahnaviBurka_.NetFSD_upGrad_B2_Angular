/* Protect page without login */
if(!localStorage.getItem("login")){
    window.location.href = "login.html";
}

let db;
let request = indexedDB.open("EventDB", 1);

/* Create database */
request.onupgradeneeded = function(e){
    db = e.target.result;
    if(!db.objectStoreNames.contains("events")){
        db.createObjectStore("events", { keyPath: "id" });
    }
};


/* When DB opens */
request.onsuccess = function(e){
    db = e.target.result;

    insertDefaultEvents();
    displayEvents();
};

request.onerror = function(e){
    console.error("DB error:", e.target.error);
};

/* Insert default events */
function insertDefaultEvents(){
    let tx = db.transaction("events", "readonly");
    let store = tx.objectStore("events");

    store.count().onsuccess = function(e){
        if(e.target.result === 0){
            let tx2 = db.transaction("events", "readwrite");
            let store2 = tx2.objectStore("events");

            store2.add({
                id: "EVT101",
                name: "AI Conference",
                category: "Tech",
                date: "2026-06-20",
                time: "10:00 AM",
                url: "https://www.upgrad.com/automation/"
            });

            store2.add({
                id: "EVT102",
                name: "Industrial Summit",
                category: "Industrial",
                date: "2026-06-25",
                time: "02:00 PM",
                url: "https://www.upgrad.com/automation/"
            });
        }
    };
}

/* CREATE EVENT */
document.getElementById("eventForm").addEventListener("submit", function(e){
    e.preventDefault();
    // Convert time to AM/PM
let time24 = eventTime.value;
let parts = time24.split(":");

let hour = parseInt(parts[0]);
let minute = parts[1];

let ampm = hour >= 12 ? "PM" : "AM";
hour = hour % 12;
if(hour === 0) hour = 12;

let formattedTime = hour + ":" + minute + " " + ampm;

    let event = {
        id: eventId.value,
        name: eventName.value,
        category: eventCategory.value,
        date: eventDate.value,
           time: formattedTime,   
        url: eventURL.value
    };

    let tx = db.transaction("events", "readwrite");
    let store = tx.objectStore("events");

    store.put(event);

    tx.oncomplete = function(){
    alert("Event added successfully!");   // ✅ ADD THIS
    displayEvents();
    eventForm.reset();
};
});

/* DISPLAY EVENTS */
function displayEvents(){
    let container = document.getElementById("eventCards");
    container.innerHTML = "";

    let tx = db.transaction("events", "readonly");
    let store = tx.objectStore("events");

    store.openCursor().onsuccess = function(e){
        let cursor = e.target.result;

        if(cursor){
            let event = cursor.value;

            container.innerHTML += `
                <div class="col-md-4">
                    <div class="card event-card p-3 text-center">
                        <h5><u>${event.name}</u></h5>
                        <p><b>ID:</b> ${event.id}</p>
                        <p><b>Category:</b> ${event.category}</p>
                        <p><b>Date:</b> ${event.date}</p>
                        <p><b>Time:</b> ${event.time}</p>
                        <a href="${event.url}" target="_blank">Visit Event</a>
                        <button class="btn btn-danger mt-2" onclick="deleteEvent('${event.id}')">Delete</button>
                    </div>
                </div>
            `;

            cursor.continue();
        }
    };
}

/* DELETE */
function deleteEvent(id){
    let tx = db.transaction("events", "readwrite");
    tx.objectStore("events").delete(id);

    tx.oncomplete = displayEvents;
}

/* SEARCH BUTTON */
function searchEvent(){
    let value = searchInput.value.toLowerCase().trim();
    let container = document.getElementById("eventCards");
    container.innerHTML = "";

    let tx = db.transaction("events", "readonly");
    let store = tx.objectStore("events");

    let found = false;

    store.openCursor().onsuccess = function(e){
        let cursor = e.target.result;

        if(cursor){
            let event = cursor.value;

            if(event.name.toLowerCase().includes(value)){
                found = true;
                displaySingleEvent(event);
            }

            cursor.continue();
        } else {
            if(!found){
                container.innerHTML = `<h5 class="text-danger text-center">No matching events</h5>`;
            }
        }
    };

    document.getElementById("suggestions").style.display = "none";
}

/* DISPLAY SINGLE */
function displaySingleEvent(event){
    let container = document.getElementById("eventCards");

    container.innerHTML += `
        <div class="col-md-4">
            <div class="card event-card p-3 text-center">
                <h5><u>${event.name}</u></h5>
                <p><b>ID:</b> ${event.id}</p>
                <p><b>Category:</b> ${event.category}</p>
                <p><b>Date:</b> ${event.date}</p>
                <p><b>Time:</b> ${event.time}</p>

                <a href="${event.url}" target="_blank">Visit Event</a>

                <button class="btn btn-danger mt-2 w-100" 
                        onclick="deleteEvent('${event.id}')">
                    Delete
                </button>
            </div>
        </div>
    `;
}
/* 🔍 SHOW SUGGESTIONS */
function showSuggestions(){
    let input = document.getElementById("searchInput").value.toLowerCase().trim();
    let box = document.getElementById("suggestions");

    box.innerHTML = "";
    box.style.display = "block";

    // 👉 If input empty → show "Show All"
    if(input === ""){
        box.innerHTML = `
            <div class="list-group-item text-primary" 
                 onclick="showAllEvents()" style="cursor:pointer;">
                Show All Events
            </div>
        `;
        return;
    }

    let tx = db.transaction("events", "readonly");
    let store = tx.objectStore("events");

    let found = false;

    store.openCursor().onsuccess = function(e){
        let cursor = e.target.result;

        if(cursor){
            let event = cursor.value;

            // 👉 match starting letter (like j → JFS)
            if(event.name.toLowerCase().startsWith(input)){
                found = true;

                box.innerHTML = `
                    <div class="list-group-item" 
                         onclick="selectSuggestion('${event.name}')" 
                         style="cursor:pointer;">
                        ${event.name}
                    </div>
                `;
            }

            cursor.continue();
        } else {
            if(!found){
                box.innerHTML = `
                    <div class="list-group-item text-danger">
                        No matching events
                    </div>
                `;
            }
        }
    };
}
function showAllEvents(){
    document.getElementById("searchInput").value = "";
    document.getElementById("suggestions").style.display = "none";
    displayEvents();
}

/* SELECT */
function selectSuggestion(name){
    searchInput.value = name;
    document.getElementById("suggestions").style.display = "none";
}

/* HIDE DROPDOWN OUTSIDE CLICK */
document.addEventListener("click", function(e){
    if(!e.target.closest(".position-relative")){
        document.getElementById("suggestions").style.display = "none";
    }
});

/* LOGOUT */
function logout(){
    localStorage.removeItem("login");
    window.location.href = "login.html";
}